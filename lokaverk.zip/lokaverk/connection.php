<?php 
try 
{
	
	$source = 'mysql:host=tsuts.tskoli.is;dbname=0201982499_lokaverkefniphp';
	$user = '0201982499';
	$password = 'mypassword';

	$pdo = new PDO($source, $user, $password);

	$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

	$pdo->exec('SET NAMES "utf8"');
} 

catch (Exception $e) 
{
	echo "Því miður kallinn. engin tenging" . "<br>" . $e->getMessage();	
}

?>