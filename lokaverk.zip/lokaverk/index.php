<!DOCTYPE HTML>
<html>
<head>
    <meta charset="utf-8">
    <title>Myndir</title>
    <link href="styles/SkjalFyrirCss.css" rel="stylesheet" type="text/css">
</head>

<body>
<header>
    <h1>Hér seturu inn myndir :D</h1>
</header>
<div id="wrapper">

 <?php $file = './includes/menu.php';
 if (file_exists($file) && is_readable($file)) {
 require $file;
 } else {
 throw new Exception("$file can't be found");
 } ?> 
<?php require './includes/random_image.php'; ?>
    <main>
    <br><br>
        <h2>Þetta er lokaverkefnið mitt, held þú sjáir það samt.</h2>
	  <?php
    include "connection.php";
    include "query.php";

?><br><br>
<form action="input.php" method="POST">
    Nafn:<br>
    <input type="text" name="myndheiti">
    <br><br>
    Ljósmyndari:<br>
    <input type="text" name="ljosmyndari">
    <br><br>
    Dagsetning:<br>
    <input type="text" name="dagsetning">
    <br><br>
    Flokkur:<br>
    <input type="text" name="flokkur">
    <br><br>
    Slóð:<br>
    <input type="text" name="linkur">
    <br><br>
    <input type="submit" name="submit">

</form>
    </main>
    <footer>
        <?php include './includes/footer.php'; ?>
    </footer>
</div>
</body>
</html>
