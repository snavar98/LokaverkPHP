<footer>
<p>&copy; 1998 &ndash; <?php echo date('Y') ?> Sigfús Snævar Jónsson</p>
</footer>