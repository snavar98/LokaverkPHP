<?php
 $images = [
 ['file' => 'kubbur',
 'caption' => 'A solved Rubiks cube'],
 ['file' => 'leystur',
 'caption' => 'A unsolved Rubiks cube'],
 ['file' => 'rubiks',
 'caption' => 'The founder of the Rubiks cube'],
 ['file' => '2x2',
 'caption' => 'A 2x2 Rubiks cube'],
 ['file' => '4x4',
 'caption' => 'A 4x4 Rubiks cube'],
 ['file' => 'small',
 'caption' => 'The worlds smallest Rubiks cube'],
 ['file' => 'big',
 'caption' => 'The worlds biggest Rubiks cube'],
 ['file' => 'record',
 'caption' => 'The fastest Rubiks cube solved']
 ];
 $i = rand(0, count($images)-1);
 $SelectedImage = "images/{$images[$i]['file']}.jpg";
 $Caption = $images[$i]['caption'];
 if (file_exists($SelectedImage) && is_readable($SelectedImage)) {
 $imageSize = getimagesize($SelectedImage);
 }
 ?>