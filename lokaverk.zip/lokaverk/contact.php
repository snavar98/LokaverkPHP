<?php
session_start();
$title = "Login";

$admin_credentials = [
  "username"=>"sigfus",
  "password"=>"konni"
];
if (isset($_POST['login'])) {
  $username = isset($_POST['username']) ? sanitize('username') : "";
  $password = isset($_POST['password']) ? sanitize('password') : "";
  if ($username == $admin_credentials['username'] && $password == $admin_credentials['password']) {
    $_SESSION['authenticated'] = "Administrator";
  } else {
    $_SESSION['error'] = "Ekki tókst að skrá þig inn.";
  }
}
if (isset($_POST['logout'])) {
  unset($_SESSION['authenticated']);
}
function sanitize ($variable){
  if ( ( $_POST[ $variable ] ) != "" ) {
    return strip_tags( trim( $_POST[ $variable ] ) );
  }
  else {
    return "";
  }
}
?>
<!DOCTYPE HTML>
<html>
<head>
    <meta charset="utf-8">
    <title>Contact Myndir</title>
    <link href="styles/SkjalFyrirCss.css" rel="stylesheet" type="text/css">
</head>

<body>
<header>
    <h1>Log in skjár</h1>
</header>
<div id="wrapper">
    
    <?php $file = './includes/menu.php';
    if (file_exists($file) && is_readable($file)) {
 require $file;
 } else {
 throw new Exception("$file can't be found");
 } ?> 
 <?php
if (isset($_SESSION['authenticated'])) {
echo <<<EOT
    <main><br><br>
    <h2>Þú hefur skráð þig inn.</h2>
    <form action="" method="post"><input name="logout" type="submit" value="Skrá út."</input></form>
    </main>
    <footer>
    <div id="kallinn">
    © 1998 - 2017 Sigfús Snævar Jónsson
    </div>
    </footer>
EOT;
} else {
  $error = "";
  if (isset($_SESSION['error'])) {
    $error = "<p style='color:red;'>{$_SESSION['error']}</p>";
    unset($_SESSION['error']);
  } 
echo <<<EOT
    <main>
    <br><br>
        <h2>Skráðu þig inn</h2>
      <p>Er bara að segja að það væri gaman að vita hvað þér finnst um þessa vefsíðu Konni.</p>
        {$error}
        <form method="post" action="">
        <input name="username" type="text" placeholder="Sláðu inn 'sigfus'">
        <input name="password" type="password" placeholder="Sláðu inn 'konni'">
        <input name="login" type="submit" value="Skrá inn">
      </form>
    </main>
    <footer>
    <div id="kallinn">
    © 1998 - 2017 Sigfús Snævar Jónsson
    </div>
    </footer>
    
</div>
EOT;
}
?>
</body>
</html>
