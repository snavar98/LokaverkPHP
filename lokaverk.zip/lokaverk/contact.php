<?php
    $error = ''; // notum $error ef login klikkar.
    
    // Athugum hvort búið er að fylla login form
    if (isset($_POST['login'])) 
    {
        session_start(); // skipun um að vinna með session
        
        // Athugum hvort að username og password er tómt
        if (!empty($_POST['email']) && !empty($_POST['password']))
         {
            $error = 'Vantar email og/eða lykilorð';
            
         }
        else if (!empty($_POST['email']))
        {
            $error = 'Vantar email';
        }
        else if (!empty($_POST['password']))
        {
            $error = 'Vantar password';
        } 
        else
        {
            
        }
    }
    
?>
<!DOCTYPE HTML>
<html>
<head>
    <meta charset="utf-8">
    <title>Contact Myndir</title>
    <link href="styles/SkjalFyrirCss.css" rel="stylesheet" type="text/css">
</head>

<body>
<?php
        // Ef login klikkar.
        if ($error) {
        echo "<p>" . $error . "</p>";
        }
    ?>
<header>
    <h1>Log in skjár</h1>
</header>
<div id="wrapper">
    
 <?php $file = './includes/menu.php';
 if (file_exists($file) && is_readable($file)) {
 require $file;
 } else {
 throw new Exception("$file can't be found");
 } ?> 

    <main>
    <br><br>
        <h2>Contact Us  </h2>
      <p>Er bara að segja að það væri gaman að vita hvað þér finnst um þessa vefsíðu Konni.</p>
        <form method="post" action="">
            <p>
                <label for="email">Email:</label>
                <input name="email" id="email" type="email" required>
            </p>
            <p>
                <label for="name">Password:</label>
                <input name="password" id="password" type="password" minlength="6" maxlength="16" required>
            </p><br>
            <p>
                <input name="login" type="submit" value="Log in">
            </p>
        </form>
    </main>
    <footer>
    <?php include './includes/footer.php'; ?>
    </footer>
</div>
</body>
</html>
