<!DOCTYPE HTML>
<html>
<head>
    <meta charset="utf-8">
    <title>Contact Rubik's</title>
    <link href="styles/SkjalFyrirCss.css" rel="stylesheet" type="text/css">
</head>

<body>
<header>
    <h1>Log in skjár</h1>
</header>
<div id="wrapper">
    
 <?php $file = './includes/menu.php';
 if (file_exists($file) && is_readable($file)) {
 require $file;
 } else {
 throw new Exception("$file can't be found");
 } ?> 

    <main>
    <br><br>
        <h2>Contact Us  </h2>
      <p>ER bara að segja að það væri gaman að vita hvað þér finst um þessa vefsíðu Konni. Sendu hér message til að sýna hvað þér finnst.</p>
        <form method="post" action="">
            <p>
                <label for="name">Name:</label>
                <input name="name" id="name" type="text">
            </p>
            <p>
                <label for="email">Email:</label>
                <input name="email" id="email" type="text">
            </p>
            <p>
                <label for="comments">Comments:</label>
                <textarea name="comments" id="comments"></textarea>
            </p>
            <p>
                <input name="send" type="submit" value="Send message">
            </p>
        </form>
    </main>
    <footer>
    <?php include './includes/footer.php'; ?>
    </footer>
</div>
</body>
</html>
