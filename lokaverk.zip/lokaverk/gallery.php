<!DOCTYPE HTML>
<html>
<head>
    <meta charset="utf-8">
    <title>Rubik's Photos</title>
    <link href="styles/SkjalFyrirCss.css" rel="stylesheet" type="text/css">
</head>
<body>
<header>
    <h1>Hér sérðu myndir</h1>
</header>
<div id="wrapper">
     
<?php $file = './includes/menu.php';
 if (file_exists($file) && is_readable($file)) {
 require $file;
 } else {
 throw new Exception("$file can't be found");
 } ?> 

    <main>
    
        
        <div id="gallery">
            <?php
    include "connection.php";
    include "query.php";

    foreach ($mynd as $entry) 
    {
        echo '<p><br> <h2>' . $entry[0] . '</h2><br><br> <img src="' . $entry[1] . '" style="width:481px" style="height:336px"> <br><br>';
    }
    print_r($mynd)
    ?>
?>
        </div>
    </main>
    <footer>
    <?php include './includes/footer.php'; ?>
    </footer>
</div>
</body>
</html>