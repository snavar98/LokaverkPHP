<!DOCTYPE HTML>
<html>
<head>
    <meta charset="utf-8">
    <title>Myndir</title>
    <link href="styles/SkjalFyrirCss.css" rel="stylesheet" type="text/css">
</head>
<body>
<header>
    <h1>Hér sérðu myndir</h1>
</header>
<div id="wrapper">
     
<?php $file = './includes/menu.php';
 if (file_exists($file) && is_readable($file)) {
 require $file;
 } else {
 throw new Exception("$file can't be found");
 } ?> 

    <main>
    <br><br><h2>Hér sérðu myndirnar</h2>
        
        <div id="gallery">
            <?php
    include "connection.php";
    include "query.php";

    foreach ($mynd as $entry) 
    {
        echo '<p>Myndheiti: ' . $entry[0] . '<br> Ljósmyndari: ' . $entry[1] . '<br>Dagsetning: ' . $entry[2] . '<br>Flokkur: '. $entry[3] . '<br><br> <img src="' . $entry[4] . '" style="width:481px" style="height:336px"> <br><br>';
    }
    
    ?>
        </div>
    </main>
    <footer>
    <?php include './includes/footer.php'; ?>
    </footer>
</div>
</body>
</html>