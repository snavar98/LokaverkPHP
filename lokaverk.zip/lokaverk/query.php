<?php
	try 
	{
		$sql = "select * FROM myndir";
		$result = $pdo ->query($sql);
	} 

	catch (Exception $e) 
	{
		echo "Obobob.. Það tókst ekki að ná í gögnin" . "<br>" . $e->getMessage();
	}

	while ($row = $result -> fetch()) 
	{
		$mynd[] = array($row['myndheiti'], $row['linkur']);
	}

?>