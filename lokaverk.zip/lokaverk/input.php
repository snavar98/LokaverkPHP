<?php
$servername = "10.200.10.24";
$username = "0201982499";
$password = "mypassword";
$dbname = "0201982499_lokaverkefniphp";
$myndheiti = $_POST['myndheiti'];
$ljosmyndari = $_POST['ljosmyndari'];
$dagsetning = $_POST['dagsetning'];
$flokkur = $_POST['flokkur'];
$linkur = $_POST['linkur'];

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) 
{
	die("Connection failed: " . $conn->connect_error);
}

$sql = "INSERT INTO myndir (myndheiti, ljosmyndari, dagsetning, flokkur, linkur) Values (\"$myndheiti\", \"$ljosmyndari\", \"$dagsetning\", \"$flokkur\", \"$linkur\")";

if ($conn->query($sql) === TRUE) 
{
	echo "New record created successfully";
	echo "<a href=\"http://tsuts.tskoli.is/2t/0201982499/lokaverk/index.php\">Fara til baka hér</a>";
}
else
{
	echo "ERROR: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>