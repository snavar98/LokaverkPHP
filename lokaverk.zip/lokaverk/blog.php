<!DOCTYPE HTML>
<html>
<head>
    <meta charset="utf-8">
    <title>Myndir Blog</title>
    <link href="styles/SkjalFyrirCss.css" rel="stylesheet" type="text/css">
</head>

<body>
<header>
    <h1>Japan Journey </h1>
</header>
<div id="wrapper">
    
 <?php $file = './includes/menu.php';
 if (file_exists($file) && is_readable($file)) {
 require $file;
 } else {
 throw new Exception("$file can't be found");
 } ?> 

    <main>
    <br><br>
        <h2>4. Apríl, 2017</h2>
        <p>Í dag fékk ég gagnagrunninn til að virka með verkefninu. Á eftir að breyta css skrá fyrir heimasíðu. Fékk það til að virka að setja inn myndir á 'Skrá myndir' og posta þeim svo
        á 'Skoða myndir' síðunni. Á eftir að ger log in system og setja inn fleiri linka á hvernig maður skráir inn myndirnar.</a></p>
        <h2>5. Apríl, 2017</h2>
        <p>Gerði meira við útlit siðunar. bætti við að hægt væri að sjá 'Ljósmndara', 'Dagsetningu', og 'Flokk'. prufaði aðeins í log in systeminu en býst við að klára það á morgun.<p>
        <h2>4. Maí, 2017</h2>
        <p>Klára að gera útlit og er byrjaður að vinna í log in systemi.</p>
    </main>
    <footer>
    <?php include './includes/footer.php'; ?>
    </footer>
</div>
</body>
</html>
