<!DOCTYPE HTML>
<html>
<head>
    <meta charset="utf-8">
    <title>Rubik's Blog</title>
    <link href="styles/SkjalFyrirCss.css" rel="stylesheet" type="text/css">
</head>

<body>
<header>
    <h1>Japan Journey </h1>
</header>
<div id="wrapper">
    
 <?php $file = './includes/menu.php';
 if (file_exists($file) && is_readable($file)) {
 require $file;
 } else {
 throw new Exception("$file can't be found");
 } ?> 

    <main>
    <br><br>
        <h2>4. Apríl, 2017</h2>
        <p>Í dag fékk ég gagnagrunninn til að virka með verkefninu. Á eftir að breyta css skrá fyrir heimasíðu. Fékk það til að virka að setja inn myndir á 'Skrá myndir' og posta þeim svo
        á 'Skoða myndir' síðunni. Á eftir að ger log in system og setja inn fleiri linka á hvernig maður skráir inn myndirnar.</a></p>
        <h2>February 5, 2017</h2>
        <p> Nichols's cube was held together with magnets. Nichols was granted U.S. Patent 3,655,201 on April 11, 1972, two years before Rubik invented his Cube. <a href="https://en.wikipedia.org/wiki/Rubik's_Cube#Prior_attempts">More</a></p>
        <h2>February 6, 2017</h2>
        <p>On April 9, 1970, Frank Fox applied to patent his "Spherical 3×3×3". He received his UK patent (1344259) on January 16, 1974. <a href="https://en.wikipedia.org/wiki/Rubik's_Cube#Prior_attempts">More</a></p>
        <h2>February 7, 2017</h2>
        <p>In the mid-1970s, Ernő Rubik worked at the Department of Interior Design at the Academy of Applied Arts and Crafts in Budapest. <a href="https://en.wikipedia.org/wiki/Rubik's_Cube#Rubik.27s_invention">More</a></p>
    </main>
    <footer>
    <?php include './includes/footer.php'; ?>
    </footer>
</div>
</body>
</html>
